from django.contrib import admin
from tdapp.models import *
admin.site.register(User)
admin.site.register(Admin)
